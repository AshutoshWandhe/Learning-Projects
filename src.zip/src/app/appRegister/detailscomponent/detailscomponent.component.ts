import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-detailscomponent',
  templateUrl: './detailscomponent.component.html',
  styleUrls: ['./detailscomponent.component.css']
})
export class DetailscomponentComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
