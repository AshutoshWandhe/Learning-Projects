import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-appdisplay',
  templateUrl: './appdisplay.component.html',
  styleUrls: ['./appdisplay.component.css']
})
export class AppdisplayComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
